#!/usr/bin/env python

"""Tests for `genome_mds` package."""


import unittest

from genome_mds import genome_mds


class TestGenome_mds(unittest.TestCase):
    """Tests for `genome_mds` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
