=======
History
=======

0.0.1 (2021-09-21)
------------------

* First release on PyPI.
