=====
Usage
=====

To use genome-mds in a project::

    import genome_mds
