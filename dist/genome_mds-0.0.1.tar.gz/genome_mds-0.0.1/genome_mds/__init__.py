"""Top-level package for genome-mds."""

__author__ = """Koji Ishiya"""
__email__ = 'koji.ishiya@aist.go.jp'
__version__ = '0.0.1'
